## Pyxll setup

# Unzip xlfuncs

# Get a pyxll license key
 - Get pyxll license
 - save key as pyxll.key in xlfuncs/pyxll/

# Install anaconda
 - https://www.continuum.io/downloads
 - Download appropriate installer : CPU architecture must match excels. (IF excel 64bit use 64bit Anaconda installer, if excel 32bit use 32bit installer)
 - Install **for all users**, in default folder C:\ProgramData\Anaconda2 (not necessary but if not you have to change the path in pyxll/pyxll.cfg)

# Set up Pyxll addin in excel
  - In excel 2010 - 2016 :
    Select the File menu in Excel and go to Options
      -> Add-Ins
      -> Manage: Excel Addins
      -> Go...
      -> Browse for the folder you unpacked xlfuncs to and select pyxll/pyxll.xll

# Install complete
 - You can now use the model functions in excel and the spreadsheet caparb-analytics.xlsx in xlfuncs/spreadsheets should work
