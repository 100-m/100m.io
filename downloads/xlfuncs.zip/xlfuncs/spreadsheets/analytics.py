from pyxll import xl_func
from scipy.stats import norm
from scipy.optimize import brentq
import math

@xl_func
def CGM_surv_prob(t, S0, vol, DPS, L=1.0, lmda=0):
	V0 = S0 + L*DPS
	if (L<1e-9): return 1.0
	if (DPS<1e-9): return 1.0
	d = V0*math.exp(lmda*lmda)/L/DPS
	a= math.sqrt(vol*vol*t+lmda*lmda)
	if (a<1e-9): return 1.0 * (S0 > 0.0)
	p = norm.cdf(-0.5*a + math.log(d)/a) - d * norm.cdf(-0.5*a - math.log(d)/a)
	return p

@xl_func
def G(t, r, S0, vol, DPS, L=1.0, lmda=0):
	if abs(t)<1e-9: return 0.0
	V0 = S0 + L*DPS
	d = V0*math.exp(lmda*lmda)/L/DPS
	z = math.sqrt(0.25 + 2.0*r/vol/vol)
	aux1 = math.log(d)/vol/math.sqrt(t)
	aux2 = z*vol*math.sqrt(t)
	return math.pow(d, z+0.5)*norm.cdf(-aux1-aux2)+math.pow(d,-z+0.5)*norm.cdf(-aux1+aux2)

@xl_func
def CGM_default_leg(t, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	ksi = lmda * lmda / vol / vol
	h = math.exp(r*ksi)*(G(t+ksi, r, S0, vol, DPS, L, lmda)-G(ksi, r, S0, vol, DPS, L, lmda))
	return (1.0-rec)*(1.0 - CGM_surv_prob(0, S0, vol, DPS, L, lmda) + h)

@xl_func
def CGM_risky_level(t, r, S0, vol, DPS, L=1.0, lmda=0):
	# need case where r=0
	ksi = lmda * lmda / vol / vol
	h = math.exp(r*ksi)*(G(t+ksi, r, S0, vol, DPS, L, lmda)-G(ksi, r, S0, vol, DPS, L, lmda))
	p = lambda tt : CGM_surv_prob(tt, S0, vol, DPS, L, lmda)
	return (p(0) - p(t)*math.exp(-r*t) - h)/r

@xl_func
def CGM_par_spread(t, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	s = CGM_default_leg(t, rec, r, S0, vol, DPS, L, lmda) / CGM_risky_level(t, r, S0, vol, DPS, L, lmda)
	return s

@xl_func
def CGM_upfront(t, c, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	pv = CGM_default_leg(t, rec, r, S0, vol, DPS, L, lmda) - c * CGM_risky_level(t, r, S0, vol, DPS, L, lmda)
	return pv

@xl_func
def CGM_theta(t, c, rec, r, S0, vol, DPS, L=1.0, lmda=0, dt = 0.01 ):
	dx = 0.01
	f = lambda tt : CGM_upfront(tt, c , rec, r, S0, vol, DPS, L, lmda)
	theta = (f(t+dt) - f(t))/ dt
	return theta

@xl_func
def CGM_delta(t, c, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	dx = 0.01
	f = lambda s : CGM_upfront(t, c , rec, r, s, vol, DPS, L, lmda)
	delta = (f(S0+dx) - f(S0))/ dx
	return delta * S0 #be aware that  delta is returned in notional amount, not in unit number.

@xl_func
def CGM_vega(t, c, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	dx = 0.01
	f = lambda v : CGM_upfront(t, c , rec, r, S0, v, DPS, L, lmda)
	vega = (f(vol+dx) - f(vol))/ dx
	return vega

@xl_func
def CGM_gamma(t, c, rec, r, S0, vol, DPS, L=1.0, lmda=0):
	dx = 0.01
	f = lambda s : CGM_upfront(t, c , rec, r, s, vol, DPS, L, lmda)
	gamma = (f(S0+dx) + f(S0-dx) - 2.0*f(S0)) / dx / dx
	return gamma

@xl_func
def CGM_vol_from_par_spread(spread, t, rec, r, S0, DPS, L=1.0, lmda=0):
	aux = lambda vol : CGM_par_spread(t, rec, r, S0, vol, DPS, L, lmda) - spread
	vol = brentq(aux, 0.001, 2.0, xtol=1.0e-05)
	return vol

@xl_func
def CGM_vol_from_upfront(upfront, t, c, rec, r, S0, DPS, L=1.0, lmda=0):
	aux = lambda vol : CGM_upfront(t, c, rec, r, S0, vol, DPS, L, lmda) - upfront
	vol = brentq(aux, 0.001, 2.0, xtol=1.0e-05)
	return vol

@xl_func
def CGM_upfront_to_par_spread(upfront, t, c, rec, r, S0, DPS, L, lmda):
	vol = CGM_vol_from_upfront(upfront, t, c, rec, r, S0, DPS, L, lmda)
	s = CGM_par_spread(t, rec, r, S0, vol, DPS, L, lmda)
	return s

@xl_func
def CGM_par_spread_to_upfront(par_spread, t, c, rec, r, S0, DPS, L, lmda):
	vol = CGM_vol_from_par_spread(par_spread, t, rec, r, S0, DPS, L, lmda)
	u = CGM_upfront(t, c, rec, r, S0, vol, DPS, L, lmda)
	return u

@xl_func
def CGM_eqvol_to_avol(eqvol, S0, DPS, L):
	avol = eqvol * S0 / (S0 + L*DPS)
	return avol

@xl_func
def CGM_avol_to_eqvol(avol, S0, DPS, L):
	eqvol = avol * (S0 + L*DPS) / S0
	return eqvol
